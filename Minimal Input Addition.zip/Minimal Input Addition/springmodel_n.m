n=6;
k=ones(n+1,1);
% u=ones(n+1,1)/10;
% m=ones(n+1,1)*2;
u=ones(n+1,1);
m=ones(n+1,1);
a=zeros(2*n,2*n);
for i=2:n-1
    a(2*i,[2*i-3:2*i+2])=[k(i)/m(i),u(i)/m(i),-(k(i)+k(i+1))/m(i),-(u(i)+u(i+1))/m(i),k(i+1)/m(i),u(i+1)/m(i)];   
end
for i=1:n
    a(2*i-1,2*i)=1;
end
i=1;
a(2*i,[2*i-1:2*i+2])=[-(k(i)+k(i+1))/m(i),-(u(i)+u(i+1))/m(i),k(i+1)/m(i),u(i+1)/m(i)];   
i=n;
a(2*i,[2*i-3:2*i])=[k(i)/m(i),u(i)/m(i),-(k(i)+k(i+1))/m(i),-(u(i)+u(i+1))/m(i)];      

function y=tiaohe(n)
y=0;
for i=1:n
    y=y+1/i;
end

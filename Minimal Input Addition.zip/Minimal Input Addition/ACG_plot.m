function ACG_plot(A0,B0,Axv,Azx,Azv,Bzu,Phi)

syms s
Gzu=Azx*inv(eye(size(A0,1))*s-A0)*B0+Bzu;
Gzv=Azx*inv(eye(size(A0,1))*s-A0)*Axv+Azv;
Gzv_n=Phi*Gzv;
Gzu_n=Phi*Gzu;
sp_Gzu_n=FindSpa(Gzu_n);
sp_Gzv_n=FindSpa(Gzv_n);
L=size(sp_Gzu_n,2)+size(sp_Gzv_n,1);
Indmax=zeros(L,L);
Indmax(1:size(sp_Gzv_n,1),:)=[sp_Gzv_n,sp_Gzu_n];
gsystem=Indmax';
graph1=biograph(gsystem);
view(graph1);

%%%%%%%%%%%% 

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
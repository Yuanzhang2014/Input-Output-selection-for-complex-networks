Y=cell(3,1);
Z=cell(3,1);

s=1;
M1=[s*eye(2)-a01,b01;-azx1,bzu1];
tempnull=null(M1');

T1=tempnull(1:size(a01,1),:)';
Z1=tempnull(size(a01,1)+1:size(a01,1)+size(azx1,1),:)';
Y1=T1*axv1+Z1*azv1;


M2=[s*eye(2)-a02,b02;-azx2,bzu2];
tempnull=null(M2');
T2=tempnull(1:size(a02,1),:)';
Z2=tempnull(size(a02,1)+1:size(a02,1)+size(azx2,1),:)';
Y2=T2*axv2+Z2*azv2;


M3=[s*eye(2)-a03,b03;-azx3,bzu3];
tempnull=null(M3');
T3=tempnull(1:size(a03,1),:)';
Z3=tempnull(size(a03,1)+1:size(a03,1)+size(azx3,1),:)';
Y3=T3*axv3+Z3*azv3;

Zi=blkdiag(Z1,Z2);
Zi=blkdiag(Zi,Z3);

Yi=blkdiag(Y1,Y2);
Yi=blkdiag(Yi,Y3);

Y{1}=Yi;
Z{1}=Zi;

s=0;
M1=[s*eye(2)-a01,b01;-azx1,bzu1];
tempnull=null(M1');

T1=tempnull(1:size(a01,1),:)';
Z1=tempnull(size(a01,1)+1:size(a01,1)+size(azx1,1),:)';
Y1=T1*axv1+Z1*azv1;


M2=[s*eye(2)-a02,b02;-azx2,bzu2];
tempnull=null(M2');
T2=tempnull(1:size(a02,1),:)';
Z2=tempnull(size(a02,1)+1:size(a02,1)+size(azx2,1),:)';
Y2=T2*axv2+Z2*azv2;


M3=[s*eye(2)-a03,b03;-azx3,bzu3];
tempnull=null(M3');
T3=tempnull(1:size(a03,1),:)';
Z3=tempnull(size(a03,1)+1:size(a03,1)+size(azx3,1),:)';
Y3=T3*axv3+Z3*azv3;

Zi=blkdiag(Z1,Z2);
Zi=blkdiag(Zi,Z3);

Yi=blkdiag(Y1,Y2);
Yi=blkdiag(Yi,Y3);

Y{2}=Yi;
Z{2}=Zi;

s=-1;
M1=[s*eye(2)-a01,b01;-azx1,bzu1];
tempnull=null(M1');

T1=tempnull(1:size(a01,1),:)';
Z1=tempnull(size(a01,1)+1:size(a01,1)+size(azx1,1),:)';
Y1=T1*axv1+Z1*azv1;


M2=[s*eye(2)-a02,b02;-azx2,bzu2];
tempnull=null(M2');
T2=tempnull(1:size(a02,1),:)';
Z2=tempnull(size(a02,1)+1:size(a02,1)+size(azx2,1),:)';
Y2=T2*axv2+Z2*azv2;


M3=[s*eye(2)-a03,b03;-azx3,bzu3];
tempnull=null(M3');
T3=tempnull(1:size(a03,1),:)';
Z3=tempnull(size(a03,1)+1:size(a03,1)+size(azx3,1),:)';
Y3=T3*axv3+Z3*azv3;

Zi=blkdiag(Z1,Z2);
Zi=blkdiag(Zi,Z3);

Yi=blkdiag(Y1,Y2);
Yi=blkdiag(Yi,Y3);

Y{3}=Yi;
Z{3}=Zi;


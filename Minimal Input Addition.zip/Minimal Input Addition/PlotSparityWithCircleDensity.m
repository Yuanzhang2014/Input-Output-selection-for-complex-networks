data1=xlsread('DataSparityComparePureGreedyTwoStep'); 
[C,IA,IC]=unique(data1(:,1));
sta_1=zeros(numel(C),3);

plot(data1(:,2),data1(:,3),'+','linewidth',1.2)
xlabel('Approximated Sparsity of Two-Stage Method')
ylabel('Approximated Sparsity of Pure-Greedy')
% hold on
% x=0:10;
% y=0:10;
% plot(x,y,'r');
hold on
PlotDiscreteDensityCirle(data1(:,2),data1(:,3));
 axis equal 
xlim([0,10.5]);
ylim([0,10.5]);

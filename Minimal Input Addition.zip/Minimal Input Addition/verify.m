clear
for i=1:10000
a1_a2=rand();
d1_d2=rand;
b_1_b2_th=sqrt(a1_a2*d1_d2);
b1_b2=b_1_b2_th-0.001;
%b1_b2_th=sqrt(a1_a2*d1_d2);
a2=rand;
d2=rand;
b2_th=sqrt(a2*d2);
b2=b2_th-0.001;
a2*d2-b2^2;
a1=a2+a1_a2;
d1=d2+d1_d2;
b1_th=sqrt(a1*d1)-0.001;
b1_th_b2=b2+b1_b2;
b1=min(b1_th,b1_th_b2)-0.001;
a1*d1-b1^2;
(a1-a2)*(d1-d2)-(b1-b2)^2;
w1=[a1 b1;b1 d1];
w2=[a2 b2;b2 d2];
w=inv(w2)-inv(w1);
%w
%det(w)
if(det(w)<0)
    disp('done')
end
end
n=50;
R = sprand(n,n,0.15);
f=full(R);
for i=1:n*n
    if f(i)>0 & f(i)<0.333
        f(i)=1;
    elseif f(i)>=0.333 & f(i)<0.666
        f(i)=-1;
    else f(i)=0;
    end   
end
% a=f;
% pos=a~=0;
% a(pos)=1;
% eig(a)
val=eig(f);
sort(val)
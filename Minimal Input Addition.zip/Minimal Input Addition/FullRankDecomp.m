function [K,L]=FullRankDecomp(X)

[U S V] = svd(X) ;

[D1 D2] = splitD(S) ;

K = U*D1 ;
L = D2*V' ;
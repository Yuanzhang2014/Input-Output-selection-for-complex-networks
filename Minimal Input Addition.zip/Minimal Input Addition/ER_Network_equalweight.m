function A=ER_Network_equalweight(n,p)
A=zeros(n,n);
for i=1:n
    for j=1:n
        r=rand();
        if r<p
            A(i,j)=1;
        end        
    end
end
for i=1:n
    A(i,i)=0;
end

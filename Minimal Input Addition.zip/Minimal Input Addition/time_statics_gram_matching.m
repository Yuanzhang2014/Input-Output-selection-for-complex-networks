clear


d_avg=4; % <k> the average degree= d_in+d_out
N=40;



A=ER_Network(N,d_avg/(N-1));
maxeigreal=max(real(eig(A)));
if maxeigreal>-1e-2  % stablize A
A=A-eye(N)*1.1*maxeigreal;
end
%%%% Gram 
% tic;
% %begin timing
% maxeigval=max(eig(A));
% A0=A;
% if abs(maxeigval)>1
%     A0=A/(abs(maxeigval)*1.2);
% end
tic;
cand=1:N;
chosen=[];
gramrank=0;
b=[];
c0=zeros(1,N);
gramrank=0;%inital gc
Bfull=eye(N)*10;
   
while gramrank<N
         temp=0;
    for bi=cand %candidate
        e_bi=Bfull(:,bi);
        b_tempgram=[b,e_bi];% sys��bȡ[ ]���Լ���
    sys = ss(A,b_tempgram,c0,[]);
    gcn = gram(sys,'c');
    %gcnrank=rank(gcn);
    % ��������ֵ�ֽ�õ��ȸ���
%     gcnrank=svdrank(gcn); %����ֵ��ֵΪ1e-4;
    gcnrank=rank(gcn); 
    deltagc=gcnrank-gramrank; %gramrank keep canstant
    if deltagc>temp
        temp=deltagc;
        e_chosen=bi;
    end   
    end
     gramrank=gramrank+temp; %update gramrank
    b=[b,Bfull(:,e_chosen)]; %update b
    chosen=[chosen,e_chosen]; %update chosen
    cand=setdiff(cand,e_chosen); %update cand
end
time_gram= toc;

 clear sys gcn

%% % constrained matching method
 tic; %begin timing
[eigvec,eigval]=eig(A');
% find the same eigenvalue and eigenvector, and its conjugate. %���������ͬһ�鴦��
%%%sort eigvec
eigrow=diag(eigval);
eigsort=cell(N,4); % 1. eigvalues 2. number of this eigvalues 3. position 4. if conjugate
eigcount=0;
for i=1:N
    if eigrow(i)~=10000; %�����Ѿ�ͳ�ƹ���
        eigcount=eigcount+1;
        eigsort{eigcount,1}=eigrow(i); % begin initilize 
        eigsort{eigcount,2}=1;
        eigsort{eigcount,3}=i;
        for j=i+1:N
            if abs(eigrow(i)-eigrow(j))<1e-3
                eigrow(j)=10000; %update
                 eigsort{eigcount,2}= eigsort{eigcount,2}+1;
                  eigsort{eigcount,3}=[eigsort{eigcount,3},j];     
            end
            if abs(imag(eigrow(i)))>1e-5 %һ���й���
                if abs(real(eigrow(i))-real(eigrow(j)))<1e-4 & abs(imag(eigrow(i))+imag(eigrow(j)))<1e-4
                    eigrow(j)=10000;
                    eigsort{eigcount,4}=1;
                end
            end
        end
    end      
end
%%%%
%%  matchrank
upmatchrank=0;
for i=1:eigcount
%     upmatchrank= upmatchrank+svdrank(eigvec(:,eigsort{i,3}));
  upmatchrank= upmatchrank+rank(eigvec(:,eigsort{i,3}));
end
%% the upper bound of matchrank
matcand=1:N;
matchosen=[];
matchrank=0;
while  matchrank< upmatchrank
        temp=0;
        for bi=matcand %candidate
        b_temp=[matchosen,bi];%����
        mrank_temp=0;
        for i=1:eigcount
%      mrank_temp= mrank_temp+svdrank(eigvec(b_temp,eigsort{i,3}));
       mrank_temp= mrank_temp+rank(eigvec(b_temp,eigsort{i,3}));
        end   
     deltagc=mrank_temp-matchrank; %gramrank keep canstant
       if deltagc>temp
        temp=deltagc;
        e_chosen=bi;
       end   
        end
    if temp==0
        break
    else
    matchrank=matchrank+temp; %update gramrank
    end
    matchosen=[matchosen,e_chosen]; %update chosen
    matcand=setdiff(matcand,e_chosen); %update cand
end
%%%%begin greedy searc
time_match=toc; %end timing
%%%%���Դ���
% matchb=Bfull(:,matchosen);
% f2=ctrb(A,matchb);
% matchosen
% svd(f2)
%%%%% ��¼����

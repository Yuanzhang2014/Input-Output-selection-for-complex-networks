%data1=xlsread('DataSFNetwork_time'); 
data1=xlsread('DataTimeComparePureGreedyTwoStep2018203'); 
data2= xlsread('addDataTimeComparePureGreedyTwoStep2018203');
data1=[data1;data2];
[C,IA,IC]=unique(data1(:,1));
sta_1=zeros(numel(C),3);

for i=1:numel(C)
    sta_1(i,1)=C(i);
    position=find(IC==i);
     sta_1(i,2)=mean(data1(position,2));  
        sta_1(i,3)=mean(data1(position,3)); 
end
%semilogy(sta_1(:,1),sta_1(:,2),'--r',sta_1(:,1),sta_1(:,3),'-.b','linewidth',1.9);
 plot(sta_1(:,1),sta_1(:,2),'o-r',sta_1(:,1),sta_1(:,3),'s-b','linewidth',1.9);
legend('Two-Stage Algorithm','Simple Greedy Algorithm')
xlabel('Network Size (n)','fontsize',12)
% xlabel('System Size (n)','fontsize',12)
%ylabel('Comp.Time (Seconds)','fontsize',12)
 ylabel('Average Running Time (seconds)','fontsize',12)

%ylabel('Approximated Minimal Input sparity','fontsize',12)
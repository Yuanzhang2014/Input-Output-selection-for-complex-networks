clear
Alpha=-3;
  networkrange=5:5:100;
   AvgNodeDegree=zeros(20,2);
for N=networkrange
    temp=0;
  for order=1:60
%A=ER_Network(N,d_avg/(N-1));
%A=ER_Network_equalweight(N,d_avg/(N-1));
%A=BADirectGenerate(N,-3); %Alpha=-3;
%GraphCountNumberOfLinks(Graph)
XAxis  = unique(round(logspace(0,log10(N),25)));
YAxis  = unique(round(logspace(0,log10(N),25))).^(Alpha+1);
% create the graph with the required node degree distribution:
Graph = mexGraphCreateRandomGraph(N,XAxis,YAxis,1);
temp=temp+GraphCountNumberOfLinks(Graph);
  end
   AvgNodeDegree(N/5,1)=N;
  AvgNodeDegree(N/5,2)=temp/N/60;
end
plot(log10(AvgNodeDegree(:,1)),AvgNodeDegree(:,2))
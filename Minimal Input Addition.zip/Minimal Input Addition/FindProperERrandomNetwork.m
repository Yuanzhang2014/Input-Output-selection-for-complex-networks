A=ER_Network_equalweight(30,3/30);
g=A;
DG=g;
com=g;  %��ͼ�����ǵ�һ��
DG=sparse(g);
[S,C] = graphconncomp(DG);
f=tabulate(C)
%min(f(:,2))
h = view(biograph(g'));
colors = jet(S);
for i = 1:numel(h.nodes)
h.Nodes(i).Color = colors(C(i),:);
end
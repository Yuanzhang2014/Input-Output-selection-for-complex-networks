
function [B,C]=fr(A)
% This function is used for Full rank decomposition.
% Use [B,C]=fr(A) during call the function.
% If A is a m*n matrix.
% B is the m*r matrix; C is the r*n matrix.

[R,jb]=rref(A);
B=A(:,jb);
C=R(1:length(jb),:);
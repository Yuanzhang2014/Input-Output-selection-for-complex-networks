data1=xlsread('DataSFNetwork_time'); 
[C,IA,IC]=unique(data1(:,1));
sta_1=zeros(numel(C),3);

for i=1:numel(C)
    sta_1(i,1)=C(i);
    position=find(IC==i);
     sta_1(i,2)=mean(data1(position,2));  
        sta_1(i,3)=mean(data1(position,3)); 
end
%semilogy(sta_1(:,1),sta_1(:,2),'--r',sta_1(:,1),sta_1(:,3),'-.b','linewidth',1.9);
 plot(sta_1(:,1),sta_1(:,2),'s-r',sta_1(:,1),sta_1(:,3),'-.b','linewidth',1.9);
legend('Grammian','Constrained Matching')
xlabel('network size (n)','fontsize',12)
%ylabel('Comp.Time (Seconds)','fontsize',12)
 ylabel('average running time (seconds)','fontsize',12)
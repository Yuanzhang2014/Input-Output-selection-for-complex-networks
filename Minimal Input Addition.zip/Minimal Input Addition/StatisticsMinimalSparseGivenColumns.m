%tic; %begin timing
%[eigvec,eigval]=eig(A');
clc;
clear;
N=200;
p=0.3;
dmax=3;
Nrange=260:20:500;

%%%��¼���ݵ��ļ�
Filename='StatisticsMinimalSparseGivenColumns.txt';
% Filename='try.txt';
CellFileP=fopen(Filename,'a+');
fprintf(CellFileP,'%s','N');
 fprintf(CellFileP,' ');
 fprintf(CellFileP,'%s','order');
  fprintf(CellFileP,' ');
  fprintf(CellFileP,'%s','Dignal');
   fprintf(CellFileP,' ');
    fprintf(CellFileP,'%s','dmax');
   fprintf(CellFileP,' ');
    fprintf(CellFileP,'%s','dmax+1');
   fprintf(CellFileP,' ');
    fprintf(CellFileP,'%s','dmax+2');
   fprintf(CellFileP,' ');
    fprintf(CellFileP,'\r\n');
fclose(CellFileP);
for N=Nrange
    for order=1:20

[eigvec,eigrow]=RandMultipleEigenDynamics(N,p,dmax);
EigRowOriginal=eigrow;
eigvec=eigvec';
 
% find the same eigenvalue and eigenvector, and its conjugate. %���������ͬһ�鴦��
%%%sort eigvec
%eigrow=diag(eigval);
eigsort=cell(N,4); % 1. eigvalues 2. number of this eigvalues 3. position 4. if conjugate
eigcount=0;
for i=1:N
    if eigrow(i)~=10000; %�����Ѿ�ͳ�ƹ���
        eigcount=eigcount+1;
        eigsort{eigcount,1}=eigrow(i); % begin initilize 
        eigsort{eigcount,2}=1;
        eigsort{eigcount,3}=i;
        for j=i+1:N
            if abs(eigrow(i)-eigrow(j))<1e-3
                eigrow(j)=10000; %update
                 eigsort{eigcount,2}= eigsort{eigcount,2}+1;
                  eigsort{eigcount,3}=[eigsort{eigcount,3},j];     
            end
            if abs(imag(eigrow(i)))>1e-5 %һ���й���
                if abs(real(eigrow(i))-real(eigrow(j)))<1e-4 & abs(imag(eigrow(i))+imag(eigrow(j)))<1e-4
                    eigrow(j)=10000;
                    eigsort{eigcount,4}=1;
                end
            end
        end
    end      
end
%%%%
%%  matchrank
upmatchrank=0;
for i=1:eigcount
%     upmatchrank= upmatchrank+svdrank(eigvec(:,eigsort{i,3}));
  upmatchrank= upmatchrank+rank(eigvec(:,eigsort{i,3}));
end
%% the upper bound of matchrank
matcand=1:N;
matchosen=[];
matchrank=0;
while  matchrank< upmatchrank
        temp=0;
        for bi=matcand %candidate
        b_temp=[matchosen,bi];%����
        mrank_temp=0;
        for i=1:eigcount
%      mrank_temp= mrank_temp+svdrank(eigvec(b_temp,eigsort{i,3}));
       mrank_temp= mrank_temp+rank(eigvec(b_temp,eigsort{i,3}));
        end   
     deltagc=mrank_temp-matchrank; %gramrank keep canstant
       if deltagc>temp
        temp=deltagc;
        e_chosen=bi;
       end   
        end
    if temp==0
        break
    else
    matchrank=matchrank+temp; %update gramrank
    end
    matchosen=[matchosen,e_chosen]; %update chosen
    matcand=setdiff(matcand,e_chosen); %update cand    
end
%%%%  generate the diagonal inputs
%%%% Generate G(h_1,h_2,...,h_N);
ListofModes=unique(EigRowOriginal);
NumofModes=length(ListofModes);
CollectofH=cell(NumofModes,2);
UnionNodesOfGraph=[];
ColorGraphConstraint=zeros(numel(matchosen),numel(matchosen));
for i=1:NumofModes
    ColIndixinV=find(EigRowOriginal==ListofModes(i)); 
    %%%%% Find the column indix of an invertible square matrix of V from V[RowIndixinV]
    %%%%% And the row indix is matchosen;  
   % for j=1:MultiplityofModes
        CollectofH{i,1}=ListofModes(i);
        CollectofH{i,2}=FindInvertibleSubmax(eigvec(matchosen, ColIndixinV)); % Generate graph G(h_1,...,h_p)
        UnionNodesOfGraph=union(UnionNodesOfGraph,CollectofH{i,2});
        for j=CollectofH{i,2}
            for jj=CollectofH{i,2}
            ColorGraphConstraint(j,jj)=1;                
            end
        end       
   % end
end
%%%%%%%%%%%%%% zero diagnoal
for i=1:numel(UnionNodesOfGraph)
    ColorGraphConstraint(i,i)=0;       
end
%%set GivenNumOfInput=pmax;
SparityOfDifferentInputs=zeros(3,1);
for GivenNumOfInput=dmax:dmax+2
%GivenNumOfInput=dmax;
%NumOfColorNodeMatch=0;
%ColorMatch=cell(numel(UnionNodesOfGraph),2); % the first: node number; the second: color number, at most twice 
%Initilize
[ColorMatch,NumOfColorNodeMatch]=GreedyLimitColoring(ColorGraphConstraint,GivenNumOfInput);
SparityOfDifferentInputs(GivenNumOfInput-dmax+1)=NumOfColorNodeMatch;
end
disp('N:');
disp(N);
disp('oder:')
disp(order);
CellFileP=fopen(Filename,'a+');
%  fprintf(CellFileP,'%s','N:'); %number of constraints
%       fprintf(CellFileP,' ');
      fprintf(CellFileP,'%d',N);
       fprintf(CellFileP,' ');
%        fprintf(CellFileP,'%s','order:');
              fprintf(CellFileP,'%d',order);
%                fprintf(CellFileP,' ');
%                fprintf(CellFileP,'%s','timeGram');
                     fprintf(CellFileP,' ');
             fprintf(CellFileP,'%d',numel(UnionNodesOfGraph));
                fprintf(CellFileP,' ');
             fprintf(CellFileP,'%d',SparityOfDifferentInputs(1));
%                       fprintf(CellFileP,' ');  
%                           fprintf(CellFileP,'%s','timeMatch');
                          fprintf(CellFileP,' ');
               fprintf(CellFileP,'%d',SparityOfDifferentInputs(2));
               fprintf(CellFileP,' ');
                       fprintf(CellFileP,' ');
             fprintf(CellFileP,'%d',SparityOfDifferentInputs(3));
                         fprintf(CellFileP,'\r\n');
    fclose(CellFileP);
%%%choose the maximum column sums.
%NumOfColorNodeMatch-numel(UnionNodesOfGraph)
    end
end
%%%%from h1,h2..., generate G(h_1,...,h_p)
%ColorGraphConstraint=zeros(numel(UnionNodesOfGraph),numel(UnionNodesOfGraph)); %%%
% for i=1:NumofModes
%     
% 
% 
% end
%%%%%%
%%%%%% Greedy Graph Coloring Algorithm 



%%%%%%
%%%%%%
%time_match=toc; %end timing
%%%%���Դ���
% matchb=Bfull(:,matchosen);
% f2=ctrb(A,matchb);
% matchosen
% svd(f2)
%%%��¼

t=[  1     0     0     2     0     0
     0     1     0     0     0     0
     0     0     3     0     1     0
    -1     0     0     4     0     0
     0     1     0     0     0     2
     0     0     1     0     0     0];
a=inv(t)*j*t;
data=zeros(1000,1);
for jj=1:1000
p=randperm(6);
xy=zeros(3,2);
xy(:,1)=p(1:3)';
xy(:,2)=[1 2 2]';
b=zeros(6,2);
for i=1:3
    b(xy(i,1),xy(i,2))=randi([-5,6],1,1);
end
f1=ctrb(a,b);
b;
data(jj)=rank(f1);
end
max(data)

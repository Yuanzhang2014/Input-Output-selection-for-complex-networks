% for a=-5:0.2:5
%     for b=-5:0.2:10
%           for c=-5:0.2:5
%         block1=[a b;-c a];
%         block2=[a b 0;-c a -b;0 -b a];
%         if max(eig(block1))>1 & max(eig(block2))<1
%             disp('found!')
%             break
%         end
%         end
%     end
% end

% for a=-2:0.2:2
%     for b=-2:0.2:2
%           for c=-2:0.2:2
%               for d=-2:0.2:2
%                     for e=-2:0.2:2
%                        for f=-2:0.2:2
%                              for g=-2:0.2:2
%                               for h=-2:0.2:2
%                    
%         block1=[a b;c d];
%         block2=[a b 0;c d e;f g h];
%         if max(abs(eig(block1)))>1 & max(abs(eig(block2)))<1
%             disp('found!')
%             disp(block2);
%             break
%         end
%         end
%     end
%                        end
%                     end
%               end
%           end
%     end
% end


for a=-0.9:0.2:0.9
    for b=-2:0.2:2
          for c=-2:0.2:2
              for d=-0.9:0.2:0.9
                    for e=-2:0.2:2
                       for f=-0.9:0.2:0.9
                         
       block1=[a 0 b;c d 0;0 e f];
        if max(abs(eig(block1)))>1
            disp('found!')
            disp(block2);
            break
        end
        end
    end
                       end
                    end
              end
          end



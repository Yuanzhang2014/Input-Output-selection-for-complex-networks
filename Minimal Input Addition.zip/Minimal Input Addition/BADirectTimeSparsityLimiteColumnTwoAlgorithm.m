%tic; %begin timing
%[eigvec,eigval]=eig(A');
clc;
clear;
N=200;
p=0.3;
ddmax=3;
%Nrange=10:20:350;
Nrange1=10:10:100;
Nrange2=120:20:200;
Nrange3=240:40:400;
%Nrange=[10 12 15 18 30 50 70 100 130 160 200 ];
%Nrange=[70 100 130 160 200];
% Nrange=[Nrange1,Nrange2,Nrange3];
 Nrange=5:5:100;
%Nrange=100;
%%%��¼���ݵ��ļ�
Filename='20180202v14_StatisticsMinimalSparseInputCompare.txt';
%Filename='20180202.txt';
% Filename='try.txt';
CellFileP=fopen(Filename,'a+');
fprintf(CellFileP,'%s','N');
 fprintf(CellFileP,' ');
 fprintf(CellFileP,'%s','order');
  fprintf(CellFileP,' ');
  fprintf(CellFileP,'%s','Sparity d');
   fprintf(CellFileP,' ');
     fprintf(CellFileP,'%s','Sparity d+2');
   fprintf(CellFileP,' ');
     fprintf(CellFileP,'%s','Sparity d+null');
   fprintf(CellFileP,' ');
       fprintf(CellFileP,'%s','diagnoal');
   fprintf(CellFileP,' ');
    fprintf(CellFileP,'%s','TimeforTwoSteps d');
   fprintf(CellFileP,' ');
       fprintf(CellFileP,'%s','TimeforTwoSteps d+1');
   fprintf(CellFileP,' ');
       fprintf(CellFileP,'%s','TimeforTwoSteps d+3');
   fprintf(CellFileP,' ');
    fprintf(CellFileP,'%s','Sparity d');
   fprintf(CellFileP,' ');
       fprintf(CellFileP,'%s','Sparity d+2');
   fprintf(CellFileP,' ');
       fprintf(CellFileP,'%s','Sparity N');
   fprintf(CellFileP,' ');
    fprintf(CellFileP,'%s','TimeforGreedy d');
   fprintf(CellFileP,' ');
       fprintf(CellFileP,'%s','TimeforGreedy d+2');
   fprintf(CellFileP,' ');
       fprintf(CellFileP,'%s','TimeforGreedy N');
   fprintf(CellFileP,' ');
    fprintf(CellFileP,'\r\n');
fclose(CellFileP);
d_avg=3; % <k> the average degree= d_in+d_out

for N=Nrange
    for order=1:10
%clearvars -except N order p ddmax Nrange Filename
A=ER_Network_equalweight(N,d_avg/(N-1));

       % A=BADirectGenerate(N,-3); 
       % A=ER_Network(N,d_avg/(N-1));
%A=ER_Network_equalweight(N,d_avg/(N-1));
% find the same eigenvalue and eigenvector, and its conjugate. %���������ͬһ�鴦��
%%%sort eigvec
[eigvec,eigval]=eig(A');
eigrow=diag(eigval);
EigRowOriginal=eigrow;
eigsort=cell(N,4); % 1. eigvalues 2. number of this eigvalues 3. position 4. if conjugate
eigcount=0;
        
% [eigvec,eigrow,dmax]=RandMultipleEigenDynamics(N,p,ddmax);
% EigRowOriginal=eigrow;
% eigvec=eigvec';
%  
% % find the same eigenvalue and eigenvector, and its conjugate. %���������ͬһ�鴦��
% %%%sort eigvec
% %eigrow=diag(eigval);
% eigsort=cell(N,4); % 1. eigvalues 2. number of this eigvalues 3. position 4. if conjugate
% eigcount=0;
for i=1:N
    if eigrow(i)~=10000; %�����Ѿ�ͳ�ƹ���
        eigcount=eigcount+1;
        eigsort{eigcount,1}=eigrow(i); % begin initilize 
        eigsort{eigcount,2}=1;
        eigsort{eigcount,3}=i;
        for j=i+1:N
            if abs(eigrow(i)-eigrow(j))<1e-3
                eigrow(j)=10000; %update
                 eigsort{eigcount,2}= eigsort{eigcount,2}+1;
                  eigsort{eigcount,3}=[eigsort{eigcount,3},j];     
            end
            if abs(imag(eigrow(i)))>1e-5 %һ���й���
                if abs(real(eigrow(i))-real(eigrow(j)))<1e-4 & abs(imag(eigrow(i))+imag(eigrow(j)))<1e-4
                    eigrow(j)=10000;
                    eigsort{eigcount,4}=1;
                end
            end
        end
    end      
end
%%%%
%%  matchrank
upmatchrank=0; dmaxtemp=0;
for i=1:eigcount
%     upmatchrank= upmatchrank+svdrank(eigvec(:,eigsort{i,3}));
  GeoMulti=rank(eigvec(:,eigsort{i,3}));
  upmatchrank= upmatchrank+rank(eigvec(:,eigsort{i,3}));
  dmaxtemp=max(dmaxtemp,GeoMulti);
end
%% the upper bound of matchrank%% For simple greedy algorithm 

dmax=dmaxtemp;
NumOfInputRange=[dmax,dmax+2];

TimeOfInputs2Stage=zeros(3,1);
SparsityOfInputs2Stage=zeros(4,1);
TimeOrder=0;
for GivenNumOfInput=NumOfInputRange
    TimeOrder=TimeOrder+1;
tic;
matcand=1:N;
matchosen=[];
matchrank=0;
while  matchrank< upmatchrank
        temp=0;
        for bi=matcand %candidate
        b_temp=[matchosen,bi];%����
        mrank_temp=0;
        for i=1:eigcount
%      mrank_temp= mrank_temp+svdrank(eigvec(b_temp,eigsort{i,3}));
       mrank_temp= mrank_temp+rank(eigvec(b_temp,eigsort{i,3}));
        end   
     deltagc=mrank_temp-matchrank; %gramrank keep canstant
       if deltagc>temp
        temp=deltagc;
        e_chosen=bi;
       end   
        end
    if temp==0
        break
    else
    matchrank=matchrank+temp; %update gramrank
    end
    matchosen=[matchosen,e_chosen]; %update chosen
    matcand=setdiff(matcand,e_chosen); %update cand    
end
%%%%  generate the diagonal inputs
%%%% Generate G(h_1,h_2,...,h_N);

ListofModes=unique(EigRowOriginal);
NumofModes=length(ListofModes);
CollectofH=cell(NumofModes,2);
UnionNodesOfGraph=[];
ColorGraphConstraint=zeros(numel(matchosen),numel(matchosen));
Hi=zeros(NumofModes,dmax);
for i=1:NumofModes
    ColIndixinV=find(EigRowOriginal==ListofModes(i)); 
    %%%%% Find the column indix of an invertible square matrix of V from V[RowIndixinV]
    %%%%% And the row indix is matchosen;  
   % for j=1:MultiplityofModes
        CollectofH{i,1}=ListofModes(i);
        CollectofH{i,2}=FindInvertibleSubmax(eigvec(matchosen, ColIndixinV)); % Generate graph G(h_1,...,h_p)
        UnionNodesOfGraph=union(UnionNodesOfGraph,CollectofH{i,2});
        for j=CollectofH{i,2}
            for jj=CollectofH{i,2}
            ColorGraphConstraint(j,jj)=1;                
            end
        end 
        % find hi, i.e. the independent state set
        AddZeroNum=dmax-numel(CollectofH{i,2}); % to make dimension feasible
        Hi(i,:)=[CollectofH{i,2},zeros(1,AddZeroNum)];        
   % end
end


%%%%%%%%%%%%%% zero diagnoal
for i=1:numel(UnionNodesOfGraph)
    ColorGraphConstraint(i,i)=0;       
end
%%set GivenNumOfInput=pmax;
SparityOfDifferentInputs=zeros(3,1);
% GivenNumOfInput=dmax;
%GivenNumOfInput=dmax;
%NumOfColorNodeMatch=0;
%ColorMatch=cell(numel(UnionNodesOfGraph),2); % the first: node number; the second: color number, at most twice 
%Initilize
[ColorMatch,NumOfColorNodeMatch]=GreedyLimitColoring(ColorGraphConstraint,GivenNumOfInput,Hi);
%SparityOfDifferentInputs(GivenNumOfInput-dmax+1)=NumOfColorNodeMatch;
  TimeDignoalColoring=toc;
  TimeOfInputs2Stage(TimeOrder)=TimeDignoalColoring;
    SparsityOfInputs2Stage(TimeOrder)=NumOfColorNodeMatch;
end
SparsityOfInputs2Stage(4)=numel(UnionNodesOfGraph);

%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%% For Greedy Algorithm. 


TimeOfInputsSimGreedy=zeros(3,1);
SparsityOfInputsSimGreedy=zeros(3,1);
TimeOrder=0;
for GivenNumOfInput=NumOfInputRange
    TimeOrder=TimeOrder+1;
tic;
matcand=ones(N,GivenNumOfInput);
matchosen=zeros(N,GivenNumOfInput);
matchrank=0;
%E=1:N; % the base set of the matroid
while  matchrank< upmatchrank
        temp=0;
        ColCandidate=find(matcand==1);      
        for bi=ColCandidate' %candidate
             PositionMat=zeros(N,GivenNumOfInput);
             PositionMat(bi)=1;
        b_temp=matchosen+PositionMat;%����
        mrank_temp=0;
        for i=1:eigcount
%      mrank_temp= mrank_temp+svdrank(eigvec(b_temp,eigsort{i,3}));
% %%%%%%
 %   E=1:size(eigvec(:,eigsort{i,3}),1);
   % mrank_temp= mrank_temp+numel(MatroidIntersection(E,eigvec(:,eigsort{i,3})',b_temp'));
    %  mrank_temp= mrank_temp+GrankMutiplyMatroid(eigvec(:,eigsort{i,3})',b_temp);
   mrank_temp= mrank_temp+GrankOfMutiply(eigvec(:,eigsort{i,3})',b_temp);%  GrankOfMutiply
        end   
     deltagc=mrank_temp-matchrank; %gramrank keep canstant
       if deltagc>temp
        temp=deltagc;
        e_chosen=bi;
       end   
        end
    if temp==0
        break
    else
    matchrank=matchrank+temp; %update gramrank
    end
    matchosen(e_chosen)=1;  %update chosen
    matcand(e_chosen)=0;%update cand    
end
NumOfColorNodeGreedy=sum(sum(matchosen));
TimePureGreedy=toc;
TimeOfInputsSimGreedy(TimeOrder)=TimePureGreedy;
SparsityOfInputsSimGreedy(TimeOrder)=NumOfColorNodeGreedy;
end




disp('N:');
disp(N);
disp('oder:')
disp(order);
CellFileP=fopen(Filename,'a+');
%  fprintf(CellFileP,'%s','N:'); %number of constraints
%       fprintf(CellFileP,' ');
      fprintf(CellFileP,'%d',N);
       fprintf(CellFileP,' ');
%        fprintf(CellFileP,'%s','order:');
              fprintf(CellFileP,'%d',order);
%                fprintf(CellFileP,' ');
%                fprintf(CellFileP,'%s','timeGram');
                     fprintf(CellFileP,' ');
             fprintf(CellFileP,'%d',SparsityOfInputs2Stage(1));
                fprintf(CellFileP,' ');
                   fprintf(CellFileP,'%d',SparsityOfInputs2Stage(2));
                fprintf(CellFileP,' ');
                   fprintf(CellFileP,'%d',SparsityOfInputs2Stage(3));
                fprintf(CellFileP,' ');
                           fprintf(CellFileP,'%d',SparsityOfInputs2Stage(4));
                fprintf(CellFileP,' ');
             fprintf(CellFileP,'%s', num2str(TimeOfInputs2Stage(1)));
%                       fprintf(CellFileP,' ');  
%                           fprintf(CellFileP,'%s','timeMatch');
                          fprintf(CellFileP,' ');
                                       fprintf(CellFileP,'%s', num2str(TimeOfInputs2Stage(2)));
%                       fprintf(CellFileP,' ');  
%                           fprintf(CellFileP,'%s','timeMatch');
                          fprintf(CellFileP,' ');
                                       fprintf(CellFileP,'%s', num2str(TimeOfInputs2Stage(3)));
%                       fprintf(CellFileP,' ');  
%                           fprintf(CellFileP,'%s','timeMatch');
                          fprintf(CellFileP,' ');
               fprintf(CellFileP,'%d',SparsityOfInputsSimGreedy(1));
               fprintf(CellFileP,' ');
                      fprintf(CellFileP,'%d',SparsityOfInputsSimGreedy(2));
               fprintf(CellFileP,' ');
                      fprintf(CellFileP,'%d',SparsityOfInputsSimGreedy(3));
               fprintf(CellFileP,' ');
                       fprintf(CellFileP,' ');
             fprintf(CellFileP,'%s', num2str(TimeOfInputsSimGreedy(1)));
              fprintf(CellFileP,' ');
              fprintf(CellFileP,'%s', num2str(TimeOfInputsSimGreedy(2)));
              fprintf(CellFileP,' ');
              fprintf(CellFileP,'%s', num2str(TimeOfInputsSimGreedy(3)));
                         fprintf(CellFileP,'\r\n');
    fclose(CellFileP);
%%%choose the maximum column sums.
%NumOfColorNodeMatch-numel(UnionNodesOfGraph)
    end
end
%%%%from h1,h2..., generate G(h_1,...,h_p)
%ColorGraphConstraint=zeros(numel(UnionNodesOfGraph),numel(UnionNodesOfGraph)); %%%
% for i=1:NumofModes
%     
% 
% 
% end
%%%%%%
%%%%%% Greedy Graph Coloring Algorithm 



%%%%%%
%%%%%%
%time_match=toc; %end timing
%%%%���Դ���
% matchb=Bfull(:,matchosen);
% f2=ctrb(A,matchb);
% matchosen
% svd(f2)
%%%��¼

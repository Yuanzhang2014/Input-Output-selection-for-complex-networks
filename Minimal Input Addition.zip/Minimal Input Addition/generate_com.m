N=5;
ms=ones(N,1)*2; % ms === 1;
mz=ones(N,1);
 MS=2;
 MZ=1;
 MT=6;
att=zeros(6,6,N);
bt=zeros(6,2,N);
ast=zeros(1,6,N);  % 
mt=6; % ״̬
 

ats=cell(N,1); % 2 X 6 ǰһ���
ass=cell(N,1); % 1 X 2
bs=cell(N,1);  % 2 X 2
 
flag=1;
 while(flag==1)
     pr=rand(1,N);
     p=sum(pr<prob); % AS ����
for i=1:N
    pr=rand();
%     att(:,:,i)=randint(6,6,a);
%     ast(:,:,i)=randint(1,6,a);
%     ct(:,:,i)=randint(2,6,a);    
%     
%      ats{i}=randint(6,ms(i),a);
%      ass{i}=randint(1,ms(i),a);
%      cs{i}=randint(2,ms(i),a);
     
    att(:,:,i)=randint(6,6,[-a,a]);
    ast(:,:,i)=randint(1,6,[-a,a]);
%     ct(:,:,i)=randint(2,6,[-a,a]);    
   
     ats{i}=randint(6,ms(i),[-a,a]);
     ass{i}=randint(1,ms(i),[-a,a]);
%      cs{i}=randint(2,ms(i),[-a,a]); 
if i<p+1
     bt(:,:,i)=zeros(6,2);   
     bs{i}=zeros(1,2);
else
     bt(:,:,i)=randint(6,2,[-a,a]);   
     bs{i}=randint(1,2,[-a,a]);
end;
end
 
 
%%%%%%%%%%%%%%%%%%%%%%%%% generate the subsystem connetion matrit
 com=zeros(sum(ms),sum(mz));
 i=1;
 com_i=randint(1,ms(i),sum(mz)-mz(i))+1;
            com_i(:)=com_i+mz(i);
    for j=1:ms(i)
    com(j,com_i(j))=1;
    end
for i=2:N
    com_i=randint(1,ms(i),sum(mz)-mz(i))+1;
    for j=1:length(com_i)
        if com_i(j)>sum(mz(1:i-1))
            com_i(j)=com_i(j)+mz(i);
        end
    end
    for j=1:ms(i)
    com(sum(ms(1:i-1))+j,com_i(j))=1;
    end
end
% function  x=RandDistributionOfMultiplity(n,dmax)
% x=zeros(1,dmax);
% i=dmax;
% rest=n;
% while rest>0 & i>1
%     upbound=floor(rest/i);
%     multiplity=randi(upbound+1,1,1)-1;
%     x(i)=multiplity;
%     rest=rest-multiplity*i;
%     i=i-1;
% end
%  x(i)=rest;
 
 %new!   
function  [x, dmaxReturn]=RandDistributionOfMultiplity(n,dmax)  % For each fixed maximum multiplicity $k_{\max}$ and system size $n$, eigenvalues with geometric multiplicity $k_i\in\{1,2,...,k_{\max}\}$ are generated  \emph{with equal probability in sequence until  $\sum\nolimits k_i\ge n$}.
x=zeros(1,dmax);
order=randi(dmax,1,n);
reminder=n;
diffe=n;
ii=0;
while diffe>0
    reminder=reminder-order(ii+1);
    ii=ii+1;
    diffe=reminder-order(ii+1);
end

eigendis=zeros(1,ii+1);
eigendis(1:ii)=order(1:ii);
eigendis(ii+1)=reminder;

for i=1:dmax
    x(i)=numel(find(eigendis==i));
end
dmaxReturn=max(eigendis);


% i=dmax;
% rest=n;
% while rest>0 & i>1
%     upbound=floor(rest/i);
%     multiplity=randi(upbound+1,1,1)-1;
%     x(i)=multiplity;
%     rest=rest-multiplity*i;
%     i=i-1;
% end
%  x(i)=rest;

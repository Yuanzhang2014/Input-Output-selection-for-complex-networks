data1=xlsread('DataTradeOffGivenInputs'); 
[C,IA,IC]=unique(data1(:,1));
sta_1=zeros(numel(C),3);

for i=1:numel(C)
    sta_1(i,1)=C(i);
    position=find(IC==i);
     sta_1(i,2)=mean(data1(position,2));  
        sta_1(i,3)=mean(data1(position,3)); 
end
plot(sta_1(:,1),sta_1(:,2),'--r',sta_1(:,1),sta_1(:,3),'-.b','linewidth',1.9);
legend('Gram','Constrained Matching')
xlabel('Nodes Number (N)','fontsize',12)
ylabel(' Minimal Sparity Approximation','fontsize',12)
hold on

clear
data1=xlsread('DataTradeOffGivenInputsBig'); 
[C,IA,IC]=unique(data1(:,1));
sta_1=zeros(numel(C),3);

for i=1:numel(C)
    sta_1(i,1)=C(i);
    position=find(IC==i);
     sta_1(i,2)=mean(data1(position,2));  
        sta_1(i,3)=mean(data1(position,3)); 
end
plot(sta_1(:,1),sta_1(:,2),'-*y',sta_1(:,1),sta_1(:,3),'+-g','linewidth',1.9);
%legend('Dadds1','Dadds2')
xlabel(' Number  of Nodes(N)','fontsize',12)
ylabel(' Minimal Sparity Approximation','fontsize',12)

legend('Diagonal Inputs','k_{max} Inputs','k_{max}+1 Inputs','k_{max}+2 Inputs')
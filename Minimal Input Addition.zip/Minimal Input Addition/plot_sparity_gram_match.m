data1=xlsread('DataSparityComparePureGreedyTwoStep'); 
[C,IA,IC]=unique(data1(:,1));
sta_1=zeros(numel(C),3);

plot(data1(:,2),data1(:,3),'*','linewidth',1.9)

for i=1:numel(C)
    sta_1(i,1)=C(i);
    position=find(IC==i);
     sta_1(i,2)=mean(data1(position,2));  
        sta_1(i,3)=mean(data1(position,3)); 
end
 plot(sta_1(:,1),sta_1(:,2),'--r',sta_1(:,1),sta_1(:,3),'-.b','linewidth',1.9);
%semilogy(sta_1(:,1),sta_1(:,2),'--r',sta_1(:,1),sta_1(:,3),'-.b','linewidth',1.9);
legend('Two-Stage','Simple Greedy')
xlabel('Nodes Number (N)','fontsize',12)
%  ylabel('Sparity of Inputs','fontsize',12)
ylabel('Comp. Time (seconds)','fontsize',12)
% ylabel('Number of Actuated States')
% Greedy Chosen J

J=[];
S=1:size(Y{1},2);
gJ=0;
fullrank=0;
for i=1:numel(Y)
    fullrank=rank([Y{i},Z{i}])+fullrank;
    gJ=rank(Z{i})+gJ;
end

while gJ<fullrank
    candi=setdiff(S,J);
    
    diffrank=0;
    maxdiffrank=0;
    chosen=[];
    for i=1:numel(candi)
        diffrank=0;
        for j=1:numel(Y)
        diffrank=diffrank+rank([Y{j}(:,[J,candi(i)]),Z{j}])-rank([Y{j}(:,J),Z{j}]);
        end
        if diffrank>maxdiffrank
            maxdiffrank=diffrank;
            chosen=candi(i);
        end       
    end
    
    gJ=0;
    for i=1:numel(Y)
    gJ=rank([Y{i}(:,[J,chosen]),Z{i}])+gJ;
    end  
    J=[J,chosen];  
end
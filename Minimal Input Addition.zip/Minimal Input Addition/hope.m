% fac1=rand(2,4);
% fac2=rand(4,2);
% product=fac1*fac2;
% det_pro=det(product);
% J=[1 2;1 3;1 4;2 3;2 4;3 4];
% temp=0;
% for i=1:6
%     temp_add=fac1(:,J(i,:))*fac2(J(i,:),:);
%     temp=temp+det(temp_add);
% end
% det_pro-temp

fac1=round(rand(3,5)*10);
fac2=round(rand(5,3)*10);
product=fac1*fac2;
det_pro=det(product);
 %J=[1 2 3;1 2 4;2 3 4;1 3 4];
%J=[1;2;3;4]
J=[1 2;1 3;1 4;1 5;2 3;2 4;2 5;3 4;3 5;4 5];
J1=[1 2;1 3;1 4;1 5;2 3;2 4;2 5;3 4;3 5;4 5];
J=ones(10,5)*diag([1 2 3 4 5]);
J2=zeros(10,3);
for i=1:10
J2(i,:)=setdiff(J(i,:),J1(i,:));
end
J=J2;
%J=[1 2 3 4;1 2 3 5;1 2 4 5;1 3 4 5;2 3 4 5];
temp=0;
for i=1:10
    temp_add=fac1(:,J(i,:))*fac2(J(i,:),:);
    temp=temp+det(temp_add);
end
det_pro
temp
det_pro-temp
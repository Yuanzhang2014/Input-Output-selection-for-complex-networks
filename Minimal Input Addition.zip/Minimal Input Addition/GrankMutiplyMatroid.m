function r=GrankMutiplyMatroid(NumerMat,StrucMat)% Find the generic rank of a numeric matrix multiplied by a structure matrix
%The StrucMat is formulated as a 0-1 matrix.

% [RowNum,ColNum]=size(StrucMat);
% %%%%%%%%%%%%%%% Random algorithm
% 
% RankList=zeros(10,1);
% for i=1:10
%     RandomVarible=rand(RowNum,ColNum).*StrucMat;
%     RankList(i)=rank(NumerMat*RandomVarible);
% end
E=1:size(NumerMat,2);
I=MatroidIntersection(E,NumerMat,StrucMat');
r=numel(I);



%%%%%%%%%%%%%%% Determined Algoritm 
%NumOfVarible=sum(sum(StrucMat));



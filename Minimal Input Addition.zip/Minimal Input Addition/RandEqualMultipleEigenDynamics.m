function  x=RandEqualDistributionOfMultiplity(n,dmax)
x=zeros(1,dmax);
i=dmax;
rest=n;
while rest>0 & i>1
    upbound=floor(rest/i);
    multiplity=randi(upbound+1,1,1)-1;
    x(i)=multiplity;
    rest=rest-multiplity*i;
    i=i-1;
end
 x(i)=rest;



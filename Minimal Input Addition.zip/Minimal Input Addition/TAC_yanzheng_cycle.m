load C:\Users\qinghua\Documents\MATLAB\2018_4_6mat_TAC.mat

%s1=rand();s4=(-2)*rand();s2=rand()*2;s3=rand()*1.6;s5=rand()*(-2);
s4=3;s5=3; s3=3;
nn=1/0.01+1;
zz=zeros(nn,nn);
for s1=1:0.01:2
    for s2=1:0.01:2
    xx=round((s1-1)/0.01+1);
    yy=round((s2-1)/0.01+1);
    
phi=[0 0 0 s1 0;0 0 s2 0 0;0 0 0 0 s3;0 0 0 0 0;0 s4 0 0 0;s5 0 0 0 0];
%s1=rand();s4=(-2)*rand();s2=rand()*2;s3=rand()*1.6;s5=rand()*(-2);
%phi=[0 0 0 s1 0;0 0 0 0 0;0 0 0  s3 0;0 0 0 0 0;0 s4 0 0 0;0 0 0 0 0];
A=la0+laxv*phi*inv(eye(5)-lazv*phi)*lazx;
B=lb0+laxv*phi*inv(eye(5)-lazv*phi)*lbzu;
eiga=eig(A);
for i=1:6
f1=[eiga(i)*eye(6)-A,B]; f2=svd(f1);
if min(f2)<0.01
    zz(xx,yy)=eiga(i);
%disp(eiga(i));
end
end

        end
end
  x=1:0.01:2;
  y=1:0.01:2;
mesh(x,y,zz)
xlabel('s_1');
ylabel('s_2');
zlabel('uncontrollable mode');

function PlotDiscreteDensityCirle(x,y)
%%%(x,y) are discrete pairs, probably with repeated serires. 
UniqueX=unique(x);
UniqueY=unique(y);
XYCombine=zeros(length(UniqueX)*length(UniqueY),3);
Numtemp=0;
for i=1:length(UniqueX)
    for j=1:length(UniqueY)
        Numtemp=Numtemp+1;
        XYCombine(Numtemp,1)=UniqueX(i);
        XYCombine(Numtemp,2)=UniqueY(j);
    end
end

for i=1:numel(x)
    Xposition= find(XYCombine(:,1)==x(i));
    Yposition=find(XYCombine(Xposition,2)==y(i));
    XYCombine(Xposition(Yposition),3)=XYCombine(Xposition(Yposition),3)+1;
end

MaxFrequency=max(XYCombine(:,3));
Numtemp=0;
for i=1:numel(UniqueX)
     for j=1:numel(UniqueY)
            Numtemp=Numtemp+1;
         if XYCombine(Numtemp,3)~=0
             plot(XYCombine(Numtemp,1),XYCombine(Numtemp,2),'+');
             hold on
             circle( XYCombine(Numtemp,1),XYCombine(Numtemp,2),XYCombine(Numtemp,3)/MaxFrequency/1.5);
             hold on
         end
     end
end
clear i


alpha=6;  
T=0.05;
vmax=22.6;
zeta=23.3;
q=zeros(7,1);


N=50;
C=6;
beta=zeros(C,1);
% for j=1:C
%     beta(j)=(2*C-2*j+1)/C^2;
% end
% for j=1:C
%     beta(j)=1/C;
% end
  beta=weigh_2(C);

q=zeros(C+1,1);
q(1)=-beta(1);
q(C+1)=beta(C);
for j=2:C
    q(j)=-beta(j)+beta(j-1);
end


r=vmax/zeta;
u=zeros(N-1,1);
delta=zeros(N-1,1);
for j=1:N-1
    u(j)=0;
    for jj=0:C
        u(j)=u(j)+q(jj+1)*exp(i*2*pi*j*jj/N);
    end
delta(j)= abs(1-alpha*T-u(j)*alpha*T^2*r);
end
delta


sigma=1-alpha*T;
gamma=u*alpha*T^2*r;
lambda=zeros(N-1,1);
for jj=1:N-1
    lambda(jj)=(1+sigma)/2+sqrt((1-sigma)^2+4*gamma(jj))/2;
end
lambda

disp('delta:')
max(delta)

disp('lambda:')
(abs(lambda))
%0.999960838226486
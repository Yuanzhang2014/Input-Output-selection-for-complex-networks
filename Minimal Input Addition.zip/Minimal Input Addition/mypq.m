function [P,Q]=mypq(A)
% This function is used for Full rank decomposition.
% Use [P,Q]=mypq(A) during call the function.
% If A is a m*n matrix. 
% P is the m*r matrix; Q is the r*n matrix.

%By Sun Huai-feng(sunhuaifeng��at��gmail��dot��com), 2010-8-1
B=rref(A);
[m,n]=size(A);
P0(1:m,:)=0;
Q0(:,1:n)=0;
for i=1:m
    flag=1;
   for j=1:n
       if B(i,j)==1     
           for k=1:i-1
               if B(k,j)~=0
                   flag=0;
                   break;
               end
           end
           for k=i+1:m
               if B(k,j)~=0
                   flag=0;
                   break;
               end
           end
           if flag==1
               P0=[P0,A(:,j)];
               Q0=[Q0;B(i,:)];
           end
       end     
   end 
end
[m1,n1]=size(P0);
[m2,n2]=size(Q0);
P=P0(:,2:n1);
Q=Q0(2:m2,:);